# Kaggle_Mnist
Mnist手写体识别

AlexNet 通过AlexNet修改网络参数 用来训练 Mnist手写体

Train 训练文件

Use_Net 使用文件

result.csv 使用文件生成的预测结果

sample_submission.csv 示例文件

test.csv 需要预测的Mnist手写体数据文件

train.csv 训练用的 Mnist 手写体 数据/标签 文件

test/* 都是尝试做题时的 测试文件

Model/* 训练好的 权重文件
