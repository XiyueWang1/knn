import tensorflow as tf
from AlexNet import AlexNet
import numpy as np
import pandas as pd

# 生成一个先入先出队列和一个Queuerunner, 生成文件名队列
filename_queue = tf.train.string_input_producer(["test.csv", ], shuffle=False)
# 定义Reader
reader = tf.TextLineReader()
key, value = reader.read(filename_queue)
# 定义 decoder

test_data = tf.decode_csv(value, record_defaults=[[1] for col in range(784)])
# 保证样本和标签一一对应
data_batch = tf.train.batch([test_data], batch_size=1, capacity=200, num_threads=1)

if __name__ == '__main__':
    net = AlexNet()  # 创建LeNet_5的对象
    net.forward()  # 执行前向计算
    init = tf.global_variables_initializer()  # 初始化所有tensorflow变量
    saver = tf.train.Saver()
    with tf.Session() as sess:
        sess.run(init)
        saver.restore(sess, "./Model/model.ckpt")
        coord = tf.train.Coordinator()  # 创建一个协调器, 管理线程
        threads = tf.train.start_queue_runners(coord=coord)  # 启动QueueRunner, 此时文件名队列已经进队
        list_count = []
        list_forecast = []
        for i in range(28000):
            test_data = sess.run([data_batch])[0]
            test_x_flat = test_data.reshape([-1, 28, 28, 1])  # 将数据整型
            test_x_flat = test_x_flat / 255. - 0.5
            # 将数据传入网络,并得到计算后的精度和损失
            out = sess.run(fetches=[net.fc4_out, ], feed_dict={net.in_x: test_x_flat})
            list_count.append(i+1)
            list_forecast.append(np.argmax(out[0][0]))
            if i % 1000 == 0:
                print("epoch", i)
        print(list_count)
        print(list_forecast)
        count = pd.Series(list_count, name='ImageId')
        forecast = pd.Series(list_forecast, name='Label')
        predictions = pd.concat([count, forecast], axis=1)
        # another way to handle
        save = pd.DataFrame({'ImageId': count, 'Label': forecast})
        save.to_csv('result.csv', index=False, sep=',')

        coord.request_stop()
        coord.join(threads)
