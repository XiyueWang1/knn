import tensorflow as tf
from Alex import AlexNet
import numpy as np

# 生成一个先入先出队列和一个Queuerunner, 生成文件名队列
filename_queue = tf.train.string_input_producer(["train.csv", ], shuffle=False)
# 定义Reader
reader = tf.TextLineReader()
key, value = reader.read(filename_queue)
# 定义 decoder

data = tf.decode_csv(value, record_defaults=[[1] for col in range(785)])
# 保证样本和标签一一对应
data_batch = tf.train.shuffle_batch([data], batch_size=128, capacity=200, min_after_dequeue=100, num_threads=1)

def one_hot(data):
    data = (np.arange(10) == data[:, None]).astype(np.int)
    return data

if __name__ == '__main__':
    net = AlexNet()  # 创建LeNet_5的对象
    net.forward()  # 执行前向计算
    net.backward()  # 执行后向计算
    net.acc()  # 执行精度计算
    init = tf.global_variables_initializer()  # 初始化所有tensorflow变量
    saver = tf.train.Saver()
    with tf.Session() as sess:
        sess.run(init)
        saver.restore(sess, "./Model/model.ckpt")
        coord = tf.train.Coordinator()  # 创建一个协调器, 管理线程
        threads = tf.train.start_queue_runners(coord=coord)  # 启动QueueRunner, 此时文件名队列已经进队
        for i in range(10000):
            data = sess.run([data_batch])[0]
            train_label, train_data = data[:, 0], data[:, 1:]
            train_x_flat = train_data.reshape([-1, 28, 28, 1])  # 将数据整型
            train_x_flat = train_x_flat / 255. - 0.5
            # 将数据传入网络,并得到计算后的精度和损失
            train_label = one_hot(train_label)
            acc, loss, _ = sess.run(fetches=[net.accaracy, net.loss, net.opt],
                                    feed_dict={net.in_x: train_x_flat, net.in_y: train_label})
            if i % 100 == 0:  # 每训练100次打印一次训练集精度和损失
                print("训练集精度:|", acc)
                print("训练集损失:|", loss)
                saver.save(sess, "./Model/model.ckpt")
        coord.request_stop()
        coord.join(threads)
