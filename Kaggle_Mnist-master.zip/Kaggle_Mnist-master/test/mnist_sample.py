import tensorflow as tf
import os
import numpy as np
import random
from PIL import Image
import matplotlib.image as iming


# 创建一个writer来写 TFRecords 文件
lables_path = "D:/python_prjs/Study/Tensorflow/Competition/"
train_filename = 'train.tfrecords'  # 输出文件

def one_hot(num):
    _one_hot = np.zeros(10, dtype=int)
    _one_hot[num] = 1
    return _one_hot

def saver_lables(lables_path, train_filename):
    writer = tf.python_io.TFRecordWriter(train_filename)  # 打开一个TFRecord文件并写入它
    train_label_path = os.path.join(lables_path, "train.csv")

    datas = open(train_label_path, "r")
    for i, line in enumerate(datas):
        if i == 0:
            continue
        data = line.split(",")
        lable = int(data[0])
        data = data[1:]
        example = tf.train.Example(features=tf.train.Features(feature={
            "label": tf.train.Feature(float_list=tf.train.FloatList(value=[lable])),
            "features": tf.train.Feature(bytes_list=tf.train.FeatureList(value=[data])),
        }))
        writer.write(example.SerializeToString())
    writer.close()
    # train_data = data[:, 1:]  # 取出图片数据
    # train_label = data[:, 0]  # 取出标签数据
    # print(train_data)

    # for _data, _label in zip(train_data, train_label):  # 遍历
    #     # _label = one_hot(_label)
    #     print(_label)
    #     example = tf.train.Example(features=tf.train.Features(feature={
    #         'setoff_lables': tf.train.Feature(int64_list=tf.train.Int64List(value=[_label])),
    #         'images_data': tf.train.Feature(float_list=tf.train.FloatList(value=[_data]))
    #     }))
    #     writer.write(example.SerializeToString())  # 序列化为字符串
    # writer.close()


def read_data_for_file(file, capacity, image_size):
    '''
    :param file: 数据文件
    :param capacity: 队列容量
    :param image_size: 图片大小
    :return: 图片数据, 标签
    '''
    # 创建文件队列,不限读取的数量
    filename_queue = tf.train.string_input_producer([file], num_epochs=None, shuffle=False, capacity=capacity)
    # create a reader from file queue
    reader = tf.TFRecordReader()  # 创建一个TFRecordRead对象
    # reader从文件队列中读入一个序列化的样本
    _, serialized_example = reader.read(filename_queue)  # 从这个队列中读取数据
    # 解析符号化的样本
    features = tf.parse_single_example(
        serialized_example,
        features={
            # 'class_lables': tf.FixedLenFeature([], tf.float32),
            'setoff_lables': tf.FixedLenFeature([1], tf.string),
            'images_data': tf.FixedLenFeature([], tf.string)

        }
    )
    img = tf.decode_raw(features['images_data'], tf.uint8)  # 将图片数据 转换为 uint8格式
    img = tf.reshape(img, image_size)  # 将图片reshape
    img = tf.cast(img, tf.float32) / 255. - 0.5
    # class_lable = tf.cast(features['class_lables'], tf.float32)
    setoff_lables = features['setoff_lables']
    return img, setoff_lables  # 返回图片的数据, 标签


def train_shuffle_batch(train_file_path, image_size, batch_size=10, capacity=101, num_threads=1):
    '''
    :param train_file_path: 训练集 文件路径
    :param image_size: 图片大小
    :param batch_size: 批次大小
    :param capacity: 队列大小
    :param num_threads: 线程个数
    :return: 图片数据, 图片标签
    '''
    # 读入图片数据 得到图片和标签
    images, setoff_lables = read_data_for_file(train_file_path, 10, image_size)
    # print(images.shape)
    # print(setoff_lables.shape)
    # min_after_dequeue：出队后队列中的最小数字元素，用于确保元素的混合级别。
    images_, setoff_lables_ = tf.train.shuffle_batch([images, setoff_lables], batch_size=batch_size, capacity=capacity,
                                                     min_after_dequeue=10, num_threads=num_threads)
    return images_, setoff_lables_


# init = tf.global_variables_initializer()  # 初始化tensorflow所有变量
init = tf.local_variables_initializer()
saver_lables(lables_path, train_filename)  # 调用saver_labels方法将数据保存到本地TFRecord
print("data succes..")
read_data_for_file(train_filename, 10, [784])  # 调用读取数据的方法 将数据读取出来(队列容量100, 图片size[48, 48, 3])
a = train_shuffle_batch(train_filename, [784])  # 将输入送入 train_shuffle_batch方法中洗牌
with tf.Session() as sess:
    coord = tf.train.Coordinator()  # 创建一个协调器，管理线程(必须)
    threads = tf.train.start_queue_runners(coord=coord, sess=sess)  # (固定, 必须)
    sess.run(init)  # 运行初始化所有参数
    # print(sess.run(read_data_for_file(train_filename, 2, [784])))
    aa, bb = sess.run(a)
    print(aa)