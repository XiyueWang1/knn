import tensorflow as tf
import numpy as np
from PIL import Image

# 生成一个先入先出队列和一个Queuerunner, 生成文件名队列
filename_queue = tf.train.string_input_producer(["test.csv", ], shuffle=False)
# 定义Reader
reader = tf.TextLineReader()
key, value = reader.read(filename_queue)
# 定义 decoder

test_data = tf.decode_csv(value, record_defaults=[[1] for col in range(784)])
# 保证样本和标签一一对应
data_batch = tf.train.batch([test_data], batch_size=1, capacity=200, num_threads=1)

if __name__ == '__main__':
    with tf.Session() as sess:
        coord = tf.train.Coordinator()  # 创建一个协调器, 管理线程
        threads = tf.train.start_queue_runners(coord=coord)  # 启动QueueRunner, 此时文件名队列已经进队
        for i in range(3):
            data = sess.run([data_batch])[0]
            array = np.asarray(data[0].reshape(28, 28), dtype=np.uint8)
            image = Image.fromarray(array)
            image.show()
            print(data.shape)
            # print("="*100 + "\n", train_data[:, 0])

        coord.request_stop()
        coord.join(threads)
