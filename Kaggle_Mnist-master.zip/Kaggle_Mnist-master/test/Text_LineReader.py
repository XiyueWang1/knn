import tensorflow as tf
import numpy as np
from PIL import Image
# 生成一个先入先出队列和一个Queuerunner, 生成文件名队列
filename_queue = tf.train.string_input_producer(["train.csv", ], shuffle=False)
# 定义Reader
reader = tf.TextLineReader()
key, value = reader.read(filename_queue)
# 定义 decoder

data = tf.decode_csv(value, record_defaults=[[1.0] for col in range(785)])
# 保证样本和标签一一对应
data_batch = tf.train.shuffle_batch([data], batch_size=5, capacity=200, min_after_dequeue=100, num_threads=1)

# 运行图
with tf.Session() as sess:
    coord = tf.train.Coordinator()  # 创建一个协调器, 管理线程
    threads = tf.train.start_queue_runners(coord=coord)  # 启动QueueRunner, 此时文件名队列已经进队
    for i in range(2):
        train_data = sess.run([data_batch])[0]
        label, data = train_data[:, 0], train_data[:, 1:]
        array = np.asarray(data[0].reshape(28, 28), dtype=np.uint8)
        image = Image.fromarray(array)
        print(label[0])
        image.show()
        print(data.shape)
        # print("="*100 + "\n", train_data[:, 0])

    coord.request_stop()
    coord.join(threads)
