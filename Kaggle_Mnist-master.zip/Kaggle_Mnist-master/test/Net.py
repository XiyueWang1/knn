import tensorflow as tf


class LeNet_5:
    def __init__(self):
        self.in_x = tf.placeholder(dtype=tf.float32, shape=[None, 28, 28, 1], name="in_x")
        self.in_y = tf.placeholder(dtype=tf.float32, shape=[None, 10], name="in_y")

        # 卷积层 (batch, 28, 28, 1) -> (batch, 24, 24, 6)
        self.conv1 = tf.layers.Conv2D(filters=6, kernel_size=5, strides=(1, 1),
                                      kernel_initializer=tf.truncated_normal_initializer(stddev=tf.sqrt(1 / 3)))
        # 池化层 (batch, 24, 24, 6) -> (batch, 12, 12, 6)
        self.pool1 = tf.layers.AveragePooling2D(pool_size=(2, 2), strides=(2, 2))
        # 卷积层 (batch, 12, 12, 6) -> (batch, 8, 8, 16)
        self.conv2 = tf.layers.Conv2D(filters=16, kernel_size=5, strides=(1, 1),
                                      kernel_initializer=tf.truncated_normal_initializer(stddev=tf.sqrt(1 / 8)))
        # 池化层 (batch, 8, 8, 16) -> (batch, 4, 4, 16)
        self.pool2 = tf.layers.AveragePooling2D(pool_size=(2, 2), strides=(2, 2))
        # 全链接层 (batch, 4*4*16(256)) -> (batch, 128)
        self.fc1 = tf.layers.Dense(256, kernel_initializer=tf.truncated_normal_initializer(stddev=tf.sqrt(1 / 128)))
        # 全链接层 (batch, 128) -> (batch, 10)
        self.fc2 = tf.layers.Dense(128, kernel_initializer=tf.truncated_normal_initializer(stddev=tf.sqrt(1 / 64)))

        self.fc3 = tf.layers.Dense(10, kernel_initializer=tf.truncated_normal_initializer(stddev=tf.sqrt(1 / 5)))

    def forward(self):  # 因为是还原LeNet5 所以使用sigmoid
        self.conv1_out = tf.nn.sigmoid(self.conv1(self.in_x))  # 将图片传入 conv1
        self.pool1_out = self.pool1(self.conv1_out)  # 将 conv1 的输出传入 pool1
        self.conv2_out = tf.nn.sigmoid(self.conv2(self.pool1_out))  # 将 pool1 的输出传入 conv2
        self.pool2_out = self.pool2(self.conv2_out)  # 将 conv2 的输出传入 pool2
        self.flat = tf.reshape(self.pool2_out, shape=[-1, 256])  # 将 pool2 的输出reshape成 (batch, -1(-1指这里的256,具体看计算出的图大小))
        self.fc1_out = tf.nn.relu(self.fc1(self.flat))  # 将 reshape 后的图传入 fc1
        self.fc2_out = tf.nn.relu(self.fc2(self.fc1_out))  # 将 fc1 的输出传入 fc2
        # self.fc3_out = tf.layers.dense(self.fc2_out, 10, kernel_initializer=tf.truncated_normal_initializer(stddev=tf.sqrt(1 / 64)))
        self.fc3_out = self.fc3(self.fc2_out)


    def backward(self):  # 后向计算
        self.loss = tf.reduce_mean((self.fc3_out - self.in_y) ** 2)  # 均方差
        self.opt = tf.train.AdamOptimizer(learning_rate=0.00001).minimize(self.loss)  # Adam优化器

    def acc(self):  # 精度计算(可不写, 不影响网络使用)
        self.acc1 = tf.equal(tf.argmax(self.fc2_out, 1), tf.argmax(self.in_y, 1))
        self.accaracy = tf.reduce_mean(tf.cast(self.acc1, dtype=tf.float32))
