import pandas as pd
import numpy as np

train = pd.read_csv("train.csv")
test = pd.read_csv("test.csv")
train_data = train.values[:, 1:]
train_label = train.values[:, 0]
test_data = test.values
print(test_data[:20])
print(train_data.shape)
print(train_label[:25])