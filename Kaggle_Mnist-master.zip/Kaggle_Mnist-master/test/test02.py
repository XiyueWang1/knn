import pandas as pd

a = ['one', 'two', 'three']
b = [1, 2, 3]
english_column = pd.Series(a, name='english')
number_column = pd.Series(b, name='number')
predictions = pd.concat([english_column, number_column], axis=1)
# another way to handle
save = pd.DataFrame({'1': a, '2': b})
save.to_csv('b.csv', index=False, sep=',')
