import numpy as np

# a = np.arange(5)
# # print(a)
# # def one_hot(num):
# #     a = np.zeros([num.shape[0], 10], dtype=int)
# #     a[:, num] = 1
# #     return a
# #
# # print(one_hot(a))

a = np.arange(5)
def one_hot(data):
    data = (np.arange(10) == data[:, None]).astype(np.int)
    return data

print(one_hot(a))